/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */
 
import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Label.*;
import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab04Part6Test {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify memory contents are setup properly
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 600
    public void verify_num_memory_contents() {
        run("end");
        int[] nums_expected = {3, 4, 5, 6, 7, 8};
        int[] nums_actual = getWords("nums", 0, 6);
        assertArrayEquals("\n\tContents of \"nums\" array are incorrect", nums_expected, nums_actual);
    }

    @Test(timeout=1000)  // 601
    public void verify_len_memory_contents() {  
        run("end");
        int len_actual = getWord("len", 0);
        assertEquals("\n\tValue of \"len\" is incorrect", 6, len_actual);
    }
    //////////////////////////////////////////////////////////////////////////////////////////


    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify correct registers are being used and have proper final values
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 602
    public void verify_len_register() {
        run("initialize");
        assertEquals("\n\tDuring computation, value of \"len\" should be 6 and stored in register $s0 -- ", 6, get(s0));
    }
    
    @Test(timeout=1000)  // 603
    public void verify_i_after_summation() {
        run("initialize");
        assertEquals("\n\tWhen average computation is complete, \"i\" should be 6 and stored in register $t1 -- ", 6, get(t1));
    }

    @Test(timeout=1000)  // 604
    public void verify_final_summation_value() {
        run("initialize");
        assertEquals("\n\tResult of summation should be 33 and stored in register $t0 -- ", 33, get(t0));
    }

    @Test(timeout=1000)  // 605
    public void verify_final_average_value() {
        run("initialize");
        assertEquals("\n\tResult of average computation should be 5 and stored in register $s2 -- ", 5, get(s2));
    }
    //////////////////////////////////////////////////////////////////////////////////////////


    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify computation works in general case when different arrays are supplied 
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 606
    public void verify_a_larger_array() {
        Label nums = wordData(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
        set(s0, 15);          // set len register
        set(s1, nums);        // set nums base register
        set(t0, 0);           // initialize sum register
        set(t1, 0);           // initialize i register
        run("loop");
        assertEquals("\n\tResult of summation for larger array should be 120 and stored in register $t0 -- ", 120, get(t0));
        assertEquals("\n\tResult of average computation for larger array should be 8 and stored in register $s2 -- ", 8, get(s2));
    }
 
    @Test(timeout=1000)  // 607
    public void verify_an_array_with_negative_values() {
        Label nums = wordData(-2, 11, -12, -22, 33, 40);
        set(s0, 6);           // set len register
        set(s1, nums);        // set nums base register
        set(t0, 0);           // initialize sum register
        set(t1, 0);           // initialize i register
        run("loop");
        assertEquals("\n\tResult of summation for array with negative values should be 48 and stored in register $t0 -- ", 48, get(t0));
        assertEquals("\n\tResult of average computation for larger array should be 8 and stored in register $s2 -- ", 8, get(s2));
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
