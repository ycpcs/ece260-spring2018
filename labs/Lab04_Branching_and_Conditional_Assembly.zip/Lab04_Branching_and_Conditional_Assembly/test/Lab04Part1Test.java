/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */
 
import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab04Part1Test {

    @Test(timeout=1000)  // 100
    public void verify_final_value_inited_to_7() {
        set(t0, 7);
        set(t1, 5);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=7, final value should be 16 -- ", 16, get(t0));
    }

    @Test(timeout=1000)  // 101
    public void verify_final_value_inited_to_6() {
        set(t0, 6);
        set(t1, 5);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=6, final value should be 15 -- ", 15, get(t0));
    }

    @Test(timeout=1000)  // 102
    public void verify_final_value_inited_to_5() {
        set(t0, 5);
        set(t1, 5);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=5, final value should be 14 -- ", 14, get(t0));
    }

    @Test(timeout=1000)  // 103
    public void verify_final_value_inited_to_4() {
        set(t0, 4);
        set(t1, 5);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=4, final value should be 11 -- ", 11, get(t0));
    }

    @Test(timeout=1000)  // 104
    public void verify_final_value_inited_to_3() {
        set(t0, 3);
        set(t1, 5);
        run("ece260_main");
        assertEquals("\n\tWhen initial value=3, final value should be 10 -- ", 10, get(t0));
    }
}
