import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab04Part5Test {

	@Test  // 500
	public void verify_final_value_inited_to_7() {
		set(t0, 7);
		run("ece260_main");
		assertEquals("\n\tWhen initial value=7, final value should be 4 -- ", 4, get(t0));
	}

	@Test  // 501
	public void verify_final_value_inited_to_15() {
		set(t0, 15);
		run("ece260_main");
		assertEquals("\n\tWhen initial value=15, final value should be 12 -- ", 12, get(t0));
	}

	@Test  // 502
	public void verify_final_value_inited_to_16() {
		set(t0, 16);
		run("ece260_main");
		assertEquals("\n\tWhen initial value=16, final value should be 13 -- ", 13, get(t0));
	}

	@Test  // 503
	public void verify_final_value_inited_to_17() {
		set(t0, 17);
		run("ece260_main");
		assertEquals("\n\tWhen initial value=17, final value should be 27 -- ", 27, get(t0));
	}

	@Test  // 504
	public void verify_final_value_inited_to_18() {
		set(t0, 18);
		run("ece260_main");
		assertEquals("\n\tWhen initial value=18, final value should be 28 -- ", 28, get(t0));
	}
}
