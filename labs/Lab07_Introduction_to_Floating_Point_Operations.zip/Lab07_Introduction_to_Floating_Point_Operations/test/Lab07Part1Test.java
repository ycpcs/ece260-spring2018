/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab07Part1Test {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify memory contents are setup properly
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 100
    public void verify_singles_memory_contents() {  
        run("exitProgram");
        float[] singles_array_expected = {1.4563f, 2.4564f, -4.2342f, 65.334f};
        float[] singles_array_actual = getFloats("singles", 0, 4);
        assertArrayEquals("\n\tContents of \"singles\" array are incorrect", singles_array_expected, singles_array_actual, 0);
    }
    
    @Test(timeout=1000)  // 101
    public void verify_doubles_memory_contents() {  
        run("exitProgram");
        double[] doubles_array_expected = {1.4563, 2.4564, -4.2342, 65.334};
        double[] doubles_array_actual = getDoubles("doubles", 0, 4);
        assertArrayEquals("\n\tContents of \"singles\" array are incorrect", doubles_array_expected, doubles_array_actual, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test processing on singles array
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 102
    public void verify_sX_regs_contain_final_results_of_singles_computations() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        run("ece260_main");
        float s0_val = Float.intBitsToFloat(get(s0));
        assertEquals("\n\tWhen done with computations on singles array, your results should be moved into $sX registers, value stored in $s0 should be 3.9127 -- ", 3.9127f, s0_val, 0);
        float s1_val = Float.intBitsToFloat(get(s1));
        assertEquals("\n\tWhen done with computations on singles array, your results should be moved into $sX registers, value stored in $s0 should be -1.7778001 -- ", -1.7778001f, s1_val, 0);
        float s2_val = Float.intBitsToFloat(get(s2));
        assertEquals("\n\tWhen done with computations on singles array, your results should be moved into $sX registers, value stored in $s0 should be 61.0998 -- ", 61.0998f, s2_val, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test processing on doubles array
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 103
    public void verify_tX_regs_contain_final_results_of_doubles_computations() {
        set(t0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(t1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(t2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(t3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(t4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(t5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        run("ece260_main");
        long t1_t0_bits = (((long)get(t1)) << 32) | (get(t0) & 0xffffffffL);
        double t1_t0_val = Double.longBitsToDouble(t1_t0_bits);
        assertEquals("\n\tWhen done with computations on doubles array, your results should be moved into $tX registers, value stored in $t1+$t0 should be 3.9127 -- ", 3.9127, t1_t0_val, 0);

        long t3_t2_bits = (((long)get(t3)) << 32) | (get(t2) & 0xffffffffL);
        double t3_t2_val = Double.longBitsToDouble(t3_t2_bits);
        assertEquals("\n\tWhen done with computations on doubles array, your results should be moved into $tX registers, value stored in $t3+$t2 should be -1.7778000000000005 -- ", -1.7778000000000005, t3_t2_val, 0);
        
        long t5_t4_bits = (((long)get(t5)) << 32) | (get(t4) & 0xffffffffL);
        double t5_t4_val = Double.longBitsToDouble(t5_t4_bits);
        assertEquals("\n\tWhen done with computations on doubles array, your results should be moved into $tX registers, value stored in $t5+$t4 should be 61.0998 -- ", 61.0998, t5_t4_val, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
