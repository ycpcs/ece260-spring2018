/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Label.*;
import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab08Part1Test_computeError {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Test computeError procedure
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 100
    public void verify_sX_regs_are_preserved_in_computeError_procedure() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in procedure
        run("computeError");
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s7 -- ", 7887, get(s7));
    }
    
    @Test(timeout=1000)  // 101
    public void verify_fX_regs_are_preserved_in_computeError_procedure() {
        // currently, cannot implement this test properly since MUnit cannot read $fX registers
    }
    
    @Test(timeout=1000)  // 102
    public void verify_stack_pointer_after_calling_computeError_procedure() {
        double arg0 = 1.0;
        double arg1 = 1.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        assertEquals("\n\tAfter calling \"computeError\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    @Test(timeout=1000)  // 103
    public void verify_computeError_procedure_returns_correct_result_0() {
        double arg0 = 1.0;
        double arg1 = 1.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        long v1_v0_bits = (((long)get(v1)) << 32) | (get(v0) & 0xffffffffL);
        double v1_v0_val = Double.longBitsToDouble(v1_v0_bits);
        assertEquals("\n\tWhen calling \"computeError(1.0, 1.0)\", return value in ($v1+$v0) should be 0.0 -- ", 0.0, v1_v0_val, 0);
    }
    
    @Test(timeout=1000)  // 104
    public void verify_computeError_procedure_returns_correct_result_1() {
        double arg0 = 1.0;
        double arg1 = 0.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        long v1_v0_bits = (((long)get(v1)) << 32) | (get(v0) & 0xffffffffL);
        double v1_v0_val = Double.longBitsToDouble(v1_v0_bits);
        assertEquals("\n\tWhen calling \"computeError(1.0, 0.0)\", return value in ($v1+$v0) should be 1.0 -- ", 1.0, v1_v0_val, 0);
    }
    
    @Test(timeout=1000)  // 105
    public void verify_computeError_procedure_returns_correct_result_2() {
        double arg0 = 0.0;
        double arg1 = 1.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        long v1_v0_bits = (((long)get(v1)) << 32) | (get(v0) & 0xffffffffL);
        double v1_v0_val = Double.longBitsToDouble(v1_v0_bits);
        assertEquals("\n\tWhen calling \"computeError(0.0, 1.0)\", return value in ($v1+$v0) should be 1.0 -- ", 1.0, v1_v0_val, 0);
    }
    
    @Test(timeout=1000)  // 106
    public void verify_computeError_procedure_returns_correct_result_3() {
        double arg0 = 1.5239;
        double arg1 = 8.7355;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        long v1_v0_bits = (((long)get(v1)) << 32) | (get(v0) & 0xffffffffL);
        double v1_v0_val = Double.longBitsToDouble(v1_v0_bits);
        assertEquals("\n\tWhen calling \"computeError(1.5239, 8.7355)\", return value in ($v1+$v0) should be 7.2116 -- ", 7.2116, v1_v0_val, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
