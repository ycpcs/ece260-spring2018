/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Label.*;
import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab06Part2Test_minIndex {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify memory contents are setup properly
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 200
    public void verify_len_memory_contents() {  
        run("exitProgram");
        int len_actual = getWord("len", 0);
        assertEquals("\n\tValue of \"len\" is incorrect", 6, len_actual);
    }
    
    @Test(timeout=1000)  // 201
    public void verify_nums_array_memory_contents() {
        run("exitProgram");
        int[] nums_array_expected = {3, 1, 5, 2, 7, 4};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tContents of \"nums_array\" array are incorrect", nums_array_expected, nums_array_actual);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test minIndex procedure
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 209
    public void verify_sX_regs_are_preserved_in_minIndex_procedure() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in procedure
        run("minIndex", "nums_array", 0, 5);
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"minIndex\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"minIndex\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"minIndex\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"minIndex\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"minIndex\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"minIndex\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"minIndex\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"minIndex\" procedure, you used $s7 -- ", 7887, get(s7));
    }
    
    @Test(timeout=1000)  // 210
    public void verify_stack_pointer_after_calling_minIndex_procedure() {
        run("minIndex", "nums_array", 0, 5);
        assertEquals("\n\tAfter calling \"minIndex\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    @Test(timeout=1000)  // 211
    public void verify_minIndex_procedure_successfully_returns_minimum_index_base_case_0() {
        run("minIndex", "nums_array", 0, 0);
        assertEquals("\n\tWhen searching from index 0->0, \"minIndex\" return value should be 0 -- ", 0, get(v0));
    }
    
    @Test(timeout=1000)  // 212
    public void verify_minIndex_procedure_successfully_returns_minimum_index_base_case_1() {
        run("minIndex", "nums_array", 1, 1);
        assertEquals("\n\tWhen searching from index 0->0, \"minIndex\" return value should be 1 -- ", 1, get(v0));
    }
    
    @Test(timeout=1000)  // 213
    public void verify_minIndex_procedure_successfully_returns_minimum_index_base_case_2() {
        run("minIndex", "nums_array", 5, 5);
        assertEquals("\n\tWhen searching from index 0->0, \"minIndex\" return value should be 5 -- ", 5, get(v0));
    }

    @Test(timeout=1000)  // 214
    public void verify_minIndex_procedure_successfully_returns_minimum_index_0() {
        run("minIndex", "nums_array", 0, 5);
        assertEquals("\n\tWhen searching from index 0->5, \"minIndex\" return value should be 1 -- ", 1, get(v0));
    }
    
    @Test(timeout=1000)  // 215
    public void verify_minIndex_procedure_successfully_returns_minimum_index_1() {
        run("minIndex", "nums_array", 2, 5);
        assertEquals("\n\tWhen searching from index 2->5, \"minIndex\" return value should be 3 -- ", 3, get(v0));
    }
    
    @Test(timeout=1000)  // 216
    public void verify_minIndex_procedure_successfully_returns_minimum_index_2() {
        run("minIndex", "nums_array", 2, 3);
        assertEquals("\n\tWhen searching from index 2->3, \"minIndex\" return value should be 3 -- ", 3, get(v0));
    }
    
    @Test(timeout=1000)  // 217
    public void verify_minIndex_procedure_successfully_returns_minimum_index_3() {
        run("minIndex", "nums_array", 4, 5);
        assertEquals("\n\tWhen searching from index 4->5, \"minIndex\" return value should be 5 -- ", 5, get(v0));
    }
    
    @Test(timeout=1000)  // 218
    public void verify_minIndex_procedure_successfully_returns_minimum_index_4() {
        run("minIndex", "nums_array", 0, 3);
        assertEquals("\n\tWhen searching from index 0->3, \"minIndex\" return value should be 1 -- ", 1, get(v0));
    }
    
    @Test(timeout=1000)  // 219
    public void verify_minIndex_procedure_successfully_returns_minimum_index_5() {
        run("minIndex", "nums_array", 0, 1);
        assertEquals("\n\tWhen searching from index 0->1, \"minIndex\" return value should be 1 -- ", 1, get(v0));
    }
    
    @Test(timeout=1000)  // 220
    public void verify_minIndex_procedure_does_not_write_to_memory() {   
        run("minIndex", "nums_array", 0, 5);
        getWords("nums_array", 0, 6);
        // read from the stack 512 bytes (128 words) of old stack memory
        //   offset from beginning of data to bottom of stack => 
        //       (0x7FFFEFFC - 0x10010000) = 0x6FFEEFFC
        //   subtract 512 bytes (128 words) from that (0x200) to account for predicted max stack depth of 128 words
        //       (0x6FFEEFFC - 0x200) = 0x6FFEEDFC
        //   finally, choose label at beginning of .data segment and read 128 words from the computed offset
         getWords("len", 0x6FFEEDFC, 128);
        assertTrue("\n\tYour minIndex procedure has written to memory locations that it should not have modified.", noOtherMemoryModifications());
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
