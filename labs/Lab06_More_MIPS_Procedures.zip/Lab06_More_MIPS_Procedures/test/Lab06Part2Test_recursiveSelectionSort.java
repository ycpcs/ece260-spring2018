/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Label.*;
import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab06Part2Test_recursiveSelectionSort {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify memory contents are setup properly
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 200
    public void verify_len_memory_contents() {  
        run("exitProgram");
        int len_actual = getWord("len", 0);
        assertEquals("\n\tValue of \"len\" is incorrect", 6, len_actual);
    }
    
    @Test(timeout=1000)  // 201
    public void verify_nums_array_memory_contents() {
        run("exitProgram");
        int[] nums_array_expected = {3, 1, 5, 2, 7, 4};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tContents of \"nums_array\" array are incorrect", nums_array_expected, nums_array_actual);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test selection sort procedure
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 221
    public void verify_sX_regs_are_preserved_in_recursiveSelectionSort_procedure() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in procedure
        run("recursiveSelectionSort", "nums_array", 6, 0);
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"recursiveSelectionSort\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"recursiveSelectionSort\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"recursiveSelectionSort\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"recursiveSelectionSort\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"recursiveSelectionSort\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"recursiveSelectionSort\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"recursiveSelectionSort\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"recursiveSelectionSort\" procedure, you used $s7 -- ", 7887, get(s7));
    }
    
    @Test(timeout=1000)  // 222
    public void verify_stack_pointer_after_calling_recursiveSelectionSort_procedure() {
        run("recursiveSelectionSort", "nums_array", 6, 0);
        assertEquals("\n\tAfter calling \"recursiveSelectionSort\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    @Test(timeout=1000)  // 223
    public void verify_recursiveSelectionSort_procedure_successfully_returns_from_base_case() {
        run("recursiveSelectionSort", "nums_array", 6, 6);
        int[] nums_array_expected = {3, 1, 5, 2, 7, 4};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tWhen calling \"recursiveSelectionSort\" and (index == len) \"nums_array\" should not change -- ", nums_array_expected, nums_array_actual);
    }
    
    @Test(timeout=1000)  // 224
    public void verify_recursiveSelectionSort_procedure_successfully_sorts_array() {
        run("recursiveSelectionSort", "nums_array", 6, 0);
        int[] nums_array_expected = {1, 2, 3, 4, 5, 7};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tWhen calling \"recursiveSelectionSort\" \"nums_array\" should get sorted -- ", nums_array_expected, nums_array_actual);
    }
    
    @Test(timeout=1000)  // 225
    public void verify_recursiveSelectionSort_procedure_successfully_sorts_already_sorted_array() {
        Label test_array = wordData(1, 2, 3, 4, 5, 7);
        run("recursiveSelectionSort", test_array, 6, 0);
        int[] test_array_expected = {1, 2, 3, 4, 5, 7};
        int[] test_array_actual = getWords(test_array, 0, 6);
        assertArrayEquals("\n\tWhen calling \"recursiveSelectionSort\" \"nums_array\" should get sorted -- ", test_array_expected, test_array_actual);
    }
    
    @Test(timeout=1000)  // 226
    public void verify_recursiveSelectionSort_procedure_successfully_sorts_larger_array() {
        Label test_array = wordData(101, 37, 53, 19, 31, 107, 97, 29, 15, 59, 73, 5, 11, 7, 109, 79, 43, 103, 13, 23, 71, 89, 9, 3, 61, 67, 83, 2, 47, 41);
        run("recursiveSelectionSort", test_array, 30, 0);
        int[] test_array_expected = {2, 3, 5, 7, 9, 11, 13, 15, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109};
        int[] test_array_actual = getWords(test_array, 0, 30);
        assertArrayEquals("\n\tWhen calling \"recursiveSelectionSort\" \"nums_array\" should get sorted (larger array) -- ", test_array_expected, test_array_actual);
    }
    
    @Test(timeout=1000)  // 227
    public void verify_recursiveSelectionSort_procedure_does_not_write_to_memory() {   
        run("recursiveSelectionSort", "nums_array", 6, 0);
        getWords("nums_array", 0, 6);
        // read from the stack 512 bytes (128 words) of old stack memory
        //   offset from beginning of data to bottom of stack => 
        //       (0x7FFFEFFC - 0x10010000) = 0x6FFEEFFC
        //   subtract 512 bytes (128 words) from that (0x200) to account for predicted max stack depth of 128 words
        //       (0x6FFEEFFC - 0x200) = 0x6FFEEDFC
        //   finally, choose label at beginning of .data segment and read 128 words from the computed offset
        getWords("len", 0x6FFEEDFC, 128);
        assertTrue("\n\tYour recursiveSelectionSort procedure has written to memory locations that it should not have modified.", noOtherMemoryModifications());
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
