/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Label.*;
import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab06Part2Test_swap {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify memory contents are setup properly
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 200
    public void verify_len_memory_contents() {  
        run("exitProgram");
        int len_actual = getWord("len", 0);
        assertEquals("\n\tValue of \"len\" is incorrect", 6, len_actual);
    }
    
    @Test(timeout=1000)  // 201
    public void verify_nums_array_memory_contents() {
        run("exitProgram");
        int[] nums_array_expected = {3, 1, 5, 2, 7, 4};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tContents of \"nums_array\" array are incorrect", nums_array_expected, nums_array_actual);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test swap procedure
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 202
    public void verify_sX_regs_are_preserved_in_swap_procedure() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in procedure
        run("swap", "nums_array", 0, 1);
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"swap\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"swap\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"swap\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"swap\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"swap\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"swap\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"swap\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"swap\" procedure, you used $s7 -- ", 7887, get(s7));
    }
    
    @Test(timeout=1000)  // 203
    public void verify_stack_pointer_after_calling_swap_procedure() {
        run("swap", "nums_array", 0, 1);
        assertEquals("\n\tAfter calling \"swap\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    @Test(timeout=1000)  // 204
    public void verify_swap_procedure_successfully_swaps_elements_0() {
        run("swap", "nums_array", 0, 1);
        int[] nums_array_expected = {1, 3, 5, 2, 7, 4};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tAfter calling \"swap\" procedure, contents of \"nums_array\" array are incorrect -- ", nums_array_expected, nums_array_actual);
    }
    
    @Test(timeout=1000)  // 205
    public void verify_swap_procedure_successfully_swaps_elements_1() {
        run("swap", "nums_array", 1, 0);
        int[] nums_array_expected = {1, 3, 5, 2, 7, 4};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tAfter calling \"swap\" procedure, contents of \"nums_array\" array are incorrect -- ", nums_array_expected, nums_array_actual);
    }
    
    @Test(timeout=1000)  // 206
    public void verify_swap_procedure_successfully_swaps_elements_2() {
        run("swap", "nums_array", 0, 5);
        int[] nums_array_expected = {4, 1, 5, 2, 7, 3};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tAfter calling \"swap\" procedure, contents of \"nums_array\" array are incorrect -- ", nums_array_expected, nums_array_actual);
    }
    
    @Test(timeout=1000)  // 207
    public void verify_swap_procedure_successfully_swaps_elements_3() {
        run("swap", "nums_array", 2, 3);
        int[] nums_array_expected = {3, 1, 2, 5, 7, 4};
        int[] nums_array_actual = getWords("nums_array", 0, 6);
        assertArrayEquals("\n\tAfter calling \"swap\" procedure, contents of \"nums_array\" array are incorrect -- ", nums_array_expected, nums_array_actual);
    }
    
    @Test(timeout=1000)  // 208
    public void verify_swap_procedure_only_writes_to_nums_array_memory() {   
        run("swap", "nums_array", 0, 5);
        getWords("nums_array", 0, 6);
        assertTrue("\n\tYour swap procedure has written to memory locations that it should not have modified.", noOtherMemoryModifications());
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
