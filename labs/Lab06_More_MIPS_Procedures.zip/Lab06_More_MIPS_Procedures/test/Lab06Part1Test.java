/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab06Part1Test {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify memory contents are setup properly
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 100
    public void verify_len_memory_contents() {  
        run("exitProgram");
        int len_actual = getWord("len", 0);
        assertEquals("\n\tValue of \"len\" is incorrect", 21, len_actual);
    }
    
    @Test(timeout=1000)  // 101
    public void verify_nums_array_memory_contents() {
        run("exitProgram");
        int[] nums_array_expected = {2, 3, 5, 7, 9, 11, 13, 15, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71};
        int[] nums_array_actual = getWords("nums_array", 0, 21);
        assertArrayEquals("\n\tContents of \"nums_array\" array are incorrect", nums_array_expected, nums_array_actual);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test binary search procedure
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 102
    public void verify_sX_regs_are_preserved_in_binary_search_procedure_base_case() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in procedure
        run("binary_search", "nums_array", 29, 20, 1);
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s7 -- ", 7887, get(s7));
    }

    @Test(timeout=1000)  // 103
    public void verify_sX_regs_are_preserved_in_binary_search_procedure_recursive_case() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in procedure
        run("binary_search", "nums_array", 29, 0, 20);
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"binary_search\" procedure, you used $s7 -- ", 7887, get(s7));
    }
    
    @Test(timeout=1000)  // 104
    public void verify_stack_pointer_after_calling_binary_search_procedure_base_case() {
        run("binary_search", "nums_array", 29, 20, 1);
        assertEquals("\n\tAfter calling \"binary_search\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    @Test(timeout=1000)  // 105
    public void verify_stack_pointer_after_calling_binary_search_procedure_recursive_case() {
        run("binary_search", "nums_array", 29, 0, 20);
        assertEquals("\n\tAfter calling \"binary_search\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    
    @Test(timeout=1000)  // 106
    public void verify_binary_search_procedure_when_key_is_in_array_but_never_recurses() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 29, 0, 20);
        assertEquals("\n\tWhen searching for 29, \"binary_search\" return value should be 10 -- ", 10, get(v0));
    }
    
    @Test(timeout=1000)  // 107
    public void verify_binary_search_procedure_when_key_is_in_left_half_of_array() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 11, 0, 20);
        assertEquals("\n\tWhen searching for 11, \"binary_search\" return value should be 5 -- ", 5, get(v0));
    }
    
    @Test(timeout=1000)  // 108
    public void verify_binary_search_procedure_when_key_is_in_right_half_of_array() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 53, 0, 20);
        assertEquals("\n\tWhen searching for 53, \"binary_search\" return value should be 16 -- ", 16, get(v0));
    }
    
    @Test(timeout=1000)  // 109
    public void verify_binary_search_procedure_when_key_is_in_index_0() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 2, 0, 20);
        assertEquals("\n\tWhen searching for 2, \"binary_search\" return value should be 0 -- ", 0, get(v0));
    }
    
    @Test(timeout=1000)  // 110
    public void verify_binary_search_procedure_when_key_is_in_last_index() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 71, 0, 20);
        assertEquals("\n\tWhen searching for 71, \"binary_search\" return value should be 20 -- ", 20, get(v0));
    }
    
    @Test(timeout=1000)  // 111
    public void verify_binary_search_procedure_when_key_is_not_in_array_search_left_half() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 10, 0, 20);
        assertEquals("\n\tWhen searching for 10, \"binary_search\" return value should be -1 -- ", -1, get(v0));
    }
    
    @Test(timeout=1000)  // 112
    public void verify_binary_search_procedure_when_key_is_not_in_array_search_right_half() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 60, 0, 20);
        assertEquals("\n\tWhen searching for 60, \"binary_search\" return value should be -1 -- ", -1, get(v0));
    }
    
    @Test(timeout=1000)  // 113
    public void verify_binary_search_procedure_when_key_is_not_in_array_less_than_smallest_value() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 1, 0, 20);
        assertEquals("\n\tWhen searching for 1, \"binary_search\" return value should be -1 -- ", -1, get(v0));
    }
    
    @Test(timeout=1000)  // 114
    public void verify_binary_search_procedure_when_key_is_not_in_array_greater_than_largest_value() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", "nums_array", 99, 0, 20);
        assertEquals("\n\tWhen searching for 99, \"binary_search\" return value should be -1 -- ", -1, get(v0));
    }
    
    @Test(timeout=1000)  // 115
    public void verify_binary_search_procedure_with_a_larger_array() {
        Label len = wordData(30);
        Label test_array = wordData(2, 3, 5, 7, 9, 11, 13, 15, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109);
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("binary_search", test_array, 107, 0, 29);
        assertEquals("\n\tWhen searching for 107 in larger array, \"binary_search\" return value should be 28 -- ", 28, get(v0));
    }    
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test that binary search is called properly from main
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 116
    public void verify_arguments_are_passed_to_binary_search_procedure_from_main() {
        set(s0, 21);            // the length of the array
        set(s1, "nums_array");  // the base address of the array
        set(s2, 29);            // search for this key
        set(v0, 9999);          // set some dummy return value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen searching for 29, \"binary_search\" return value should be 10 -- ", 10, get(v0));
    }

    @Test(timeout=1000)  // 117
    public void verify_final_result_stored_properly() {
        set(s0, 21);            // the length of the array
        set(s1, "nums_array");  // the base address of the array
        set(s2, 29);            // search for this key
        set(v0, 9999);          // set some dummy return value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen calling \"binary_search\" procedure, return value should be stored in $s3 -- ", 10, get(s3));
    }
    
    @Test(timeout=1000)  // 118
    public void verify_stack_pointer_after_running_complete_program() {
        set(s0, 21);            // the length of the array
        set(s1, "nums_array");  // the base address of the array
        set(s2, 29);            // search for this key
        set(v0, 9999);          // set some dummy return value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tAfter running program, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
