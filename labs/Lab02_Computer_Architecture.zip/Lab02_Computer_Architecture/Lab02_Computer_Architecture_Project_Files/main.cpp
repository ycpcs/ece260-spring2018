
#include <iostream>
#include <string>
#include <stdint.h>
#include "definitions.h"
using namespace std;

int main()
{
	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #1 - Using a call to new, declare an array of five integers. 
	// Use printPointerInfo(string, ptr*) to print out information for the int* array
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #1 CODE HERE
	/////////////////////////////


	/////////////////////////////



	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #2 - Iterate over 'array' and use printPointerInfo to print out the memory 
	// address and the value of each index of the array. 
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #2 CODE HERE
	/////////////////////////////


	/////////////////////////////



	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #3 - Iterate over 'array' and initialize each element to '100 + index'.
	// You do not need to print anything during this iteration.
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #3 CODE HERE
	/////////////////////////////


	/////////////////////////////
	


	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #4 - After initialization, use printPointerInfo to print out the memory 
	// address and the value of each index of the array once again (same as Task #2). 
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #4 CODE HERE
	/////////////////////////////


	/////////////////////////////



	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #5 - Create a new 'int* ptr' and set that pointer equal to the 'array' created in task #1. 
	// Next, use the '+' operator and add 3 to 'int* ptr' to cause it to point to 'array[3]'.
	// Print out the memory address and value of 'ptr'.
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #5 CODE HERE
	/////////////////////////////


	/////////////////////////////



	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #6 - Use 'printPointerInfo()' to print out the memory address and value of 'main()', 
	// 'printPointerInfo()', 'getNumberOfProcessors()', and 'makeSomeThreads()'. 
	// These functions are declared in the definitions.h file
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #6 CODE HERE
	/////////////////////////////


	/////////////////////////////



	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #7 - Not all variables types consume the same amount of memory. Use the function sizeof(<type>)
	// to determine the width (in bytes) of the following variable types: byte, char, short, int, long int, long long,
	// float, double, char*, and int*. Use the website: http://www.nongnu.org/avr-libc/user-manual/group__avr__stdint.html
	// to lookup the definition for each type
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #7 CODE HERE
	/////////////////////////////


	/////////////////////////////



	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #8 - Use the functions getNumberofProcessors() and getCurrentProcessor() defined in definitions.h
	// to determine the number of processors on the current computer and the active processor for Lab02
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #8 CODE HERE
	/////////////////////////////


	/////////////////////////////


	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	// TODO: Task #9 - Call the function makeSomeThreads(int) to generate a certain number of threads.
	// pass an integer by value to create <value> number of threads.(Maximum is 10).
	// Each thread will print out a message about which processor it is running on.
	//
	cout << "****************************************************************" << endl;
	/////////////////////////////
	// YOUR Task #9 CODE HERE
	/////////////////////////////


	/////////////////////////////
	

	cout << "****************************************************************" << endl;
	system("pause");

	return 0;
}


