#ifndef _DEFS_H_
#define _DEFS_H_


#include <Windows.h>
#include <WinBase.h>
#include <tchar.h>
#include <strsafe.h>
#include <iostream>
#include <string>
using namespace std;

// Sample custom data structure for threads to use.
// This is passed by void pointer so it can be any data type
// that can be passed using a single void pointer (LPVOID).
typedef struct MyData {
	int val1;
	int val2;
} MYDATA, *PMYDATA;


#define BUF_SIZE 255

DWORD WINAPI MyThreadFunction(LPVOID lpParam);
void ErrorHandler(LPTSTR lpszFunction);

void printPointerInfo(string name, void* ptr);
int getNumberOfProcessors();
int getCurrentProcessor();

void makeSomeThreads(unsigned);

#endif