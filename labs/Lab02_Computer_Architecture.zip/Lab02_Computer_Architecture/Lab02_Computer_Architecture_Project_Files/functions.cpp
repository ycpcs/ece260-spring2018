#include "definitions.h"

// significantly edited from: https://msdn.microsoft.com/en-us/library/windows/desktop/ms682516(v=vs.85).aspx
DWORD WINAPI MyThreadFunction(LPVOID lpParam)
{
	HANDLE hStdout;
	PMYDATA pDataArray;

	TCHAR msgBuf[BUF_SIZE];
	size_t cchStringSize;
	DWORD dwChars;

	// Make sure there is a console to receive output results. 

	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hStdout == INVALID_HANDLE_VALUE)
		return 1;

	// Cast the parameter to the correct data type.
	// The pointer is known to be valid because 
	// it was checked for NULL before the thread was created.

	pDataArray = (PMYDATA)lpParam;

	// Print the parameter values using thread-safe functions.
	//string printProcessor = "\tThread " + std::to_string(pDataArray->val1) + " on Processor " + std::to_string(getCurrentProcessor());
	StringCchPrintf(msgBuf, BUF_SIZE, TEXT("\tThread %d on Processor %d\n"),
		pDataArray->val1, getCurrentProcessor());
	StringCchLength(msgBuf, BUF_SIZE, &cchStringSize);
	WriteConsole(hStdout, msgBuf, (DWORD)cchStringSize, &dwChars, NULL);

	StringCchPrintf(msgBuf, BUF_SIZE, TEXT("\tThread %d MyFunction() Address %x\n"),
		pDataArray->val1, &MyThreadFunction);
	StringCchLength(msgBuf, BUF_SIZE, &cchStringSize);
	WriteConsole(hStdout, msgBuf, (DWORD)cchStringSize, &dwChars, NULL);

	StringCchPrintf(msgBuf, BUF_SIZE, TEXT("\tThread %d MyDataArray Address %x\n"),
		pDataArray->val1, &pDataArray);
	StringCchLength(msgBuf, BUF_SIZE, &cchStringSize);
	WriteConsole(hStdout, msgBuf, (DWORD)cchStringSize, &dwChars, NULL);

	return 0;
}


// from https://msdn.microsoft.com/en-us/library/windows/desktop/ms682516(v=vs.85).aspx
void ErrorHandler(LPTSTR lpszFunction)
{
	// Retrieve the system error message for the last-error code.

	LPVOID lpMsgBuf;
	LPVOID lpDisplayBuf;
	DWORD dw = GetLastError();

	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		dw,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf,
		0, NULL);

	// Display the error message.

	lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT,
		(lstrlen((LPCTSTR)lpMsgBuf) + lstrlen((LPCTSTR)lpszFunction) + 40) * sizeof(TCHAR));
	StringCchPrintf((LPTSTR)lpDisplayBuf,
		LocalSize(lpDisplayBuf) / sizeof(TCHAR),
		TEXT("%s failed with error %d: %s"),
		lpszFunction, dw, lpMsgBuf);
	MessageBox(NULL, (LPCTSTR)lpDisplayBuf, TEXT("Error"), MB_OK);

	// Free error-handling buffer allocations.

	LocalFree(lpMsgBuf);
	LocalFree(lpDisplayBuf);
}


void printPointerInfo(string name, void* ptr)
{
	printf("%s \t Address %x \t Value %x\n", name.c_str(), ptr, *(int*)(ptr));
}


// returns the number of processors in the system
int getNumberOfProcessors()
{
	//from https://msdn.microsoft.com/en-us/library/windows/desktop/ms724423(v=vs.85).aspx
	SYSTEM_INFO siSysInfo;

	//https://msdn.microsoft.com/en-us/library/windows/desktop/ms724958(v=vs.85).aspx
	GetSystemInfo(&siSysInfo);

	return siSysInfo.dwNumberOfProcessors;
}


// returns the number of the processors you are executing on
int getCurrentProcessor()
{
	//https://msdn.microsoft.com/en-us/library/ms683181%28VS.85%29.aspx
	return GetCurrentProcessorNumber();
}


void makeSomeThreads(unsigned MAX_THREADS)
{
	//Edited https://msdn.microsoft.com/en-us/library/windows/desktop/ms682516(v=vs.85).aspx

	if (MAX_THREADS <= 0)
	{
		return;
	}
	else if (MAX_THREADS > 10)
	{
		MAX_THREADS = 10;
	}

	PMYDATA* pDataArray = new PMYDATA[MAX_THREADS];
	DWORD*   dwThreadIdArray = new DWORD[MAX_THREADS];
	HANDLE*  hThreadArray = new HANDLE[MAX_THREADS];

	for (unsigned int i = 0; i < MAX_THREADS; i++)
	{
		// Allocate memory for thread data.

		pDataArray[i] = (PMYDATA)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(MYDATA));

		if (pDataArray[i] == NULL)
		{
			// If the array allocation fails, the system is out of memory
			// so there is no point in trying to print an error message.
			// Just terminate execution.
			ExitProcess(2);
		}

		// Generate unique data for each thread to work with.

		pDataArray[i]->val1 = i;
		pDataArray[i]->val2 = i + 100;

		// Create the thread to begin execution on its own.

		hThreadArray[i] = CreateThread(
			NULL,                   // default security attributes
			0,                      // use default stack size  
			MyThreadFunction,       // thread function name
			pDataArray[i],          // argument to thread function 
			0,                      // use default creation flags 
			&dwThreadIdArray[i]);   // returns the thread identifier 


		// Check the return value for success.
		// If CreateThread fails, terminate execution. 
		// This will automatically clean up threads and memory. 

		if (hThreadArray[i] == NULL)
		{
			ErrorHandler(TEXT("CreateThread"));
			ExitProcess(3);
		}
	} // End of main thread creation loop.

	// Wait until all threads have terminated.

	WaitForMultipleObjects(MAX_THREADS, hThreadArray, TRUE, INFINITE);

	// Close all thread handles and free memory allocations.

	for (unsigned int i = 0; i < MAX_THREADS; i++)
	{
		CloseHandle(hThreadArray[i]);
		if (pDataArray[i] != NULL)
		{
			HeapFree(GetProcessHeap(), 0, pDataArray[i]);
			pDataArray[i] = NULL;    // Ensure address is not reused.
		}
	}
}