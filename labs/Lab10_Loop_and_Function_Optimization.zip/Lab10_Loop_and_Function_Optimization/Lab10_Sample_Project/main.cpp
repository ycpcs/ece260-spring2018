#include "mbed.h"

Serial pc(USBTX, USBRX); // tx, rx
Timer t;

#define LIMIT 2048
int data[LIMIT];
int result[LIMIT];



int multiply(int value, int scalar)
{
    return value * scalar;
}



int modify(int value)
{
    return multiply(value << 2, 10);
}



int main() 
{
    pc.baud(9600);  
    t.start();
    
    
    // ************************* //
    //// YOUR CODE STARTS HERE ////
    // ************************* //
    
    int sum = 0;
    for(int i = 0; i < LIMIT; i++)
    {
        // For Section 3.1 - Step 3
        sum += (10 * data[i]) << 2;
        
        // For Section 3.2 - Step 1
        //result[i] = (10 * data[i]) << 2;
        
        // For Section 3.3 - Step 1
        //result[i] = modify(data[i]);
    }
    
    // *********************** //
    //// YOUR CODE ENDS HERE ////
    // *********************** //
    
    
    t.stop();
    unsigned int time = t.read_us();
    pc.printf("CPU time is %i microseconds\r\n", time);
}
